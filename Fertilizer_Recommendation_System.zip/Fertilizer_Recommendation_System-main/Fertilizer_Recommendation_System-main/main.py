from flask import Flask, request, render_template
import pickle

app = Flask(__name__)

# Load models
model = pickle.load(open(r'A:\Fertilizer_Recommendation_System-main\Fertilizer_Recommendation_System-main\classifier.pkl', 'rb'))
ferti = pickle.load(open(r'A:\Fertilizer_Recommendation_System-main\Fertilizer_Recommendation_System-main\fertilizer.pkl', 'rb'))

# Set the only route for the homepage to Model1
@app.route('/')
def Model1():
    return render_template('Model1.html')

# Handle prediction request
@app.route('/predict', methods=['POST'])
def predict():
    temp = request.form.get('temp')
    humi = request.form.get('humid')
    mois = request.form.get('mois')
    soil = request.form.get('soil')
    crop = request.form.get('crop')
    nitro = request.form.get('nitro')
    pota = request.form.get('pota')
    phosp = request.form.get('phos')

    # Validate input
    if None in (temp, humi, mois, soil, crop, nitro, pota, phosp) or not all(val.isdigit() for val in (temp, humi, mois, soil, crop, nitro, pota, phosp)):
        return render_template('Model1.html', x='Invalid input. Please provide numeric values for all fields.')

    # Convert to integer and predict
    input_data = [int(temp), int(humi), int(mois), int(soil), int(crop), int(nitro), int(pota), int(phosp)]
    result = ferti.classes_[model.predict([input_data])]
    return render_template('Model1.html', x=result)

if __name__ == "__main__":
    app.run(debug=True)
