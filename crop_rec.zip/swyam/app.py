from flask import Flask, render_template, request
import numpy as np
import pandas as pd
import pickle
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
import os
import requests # Added for fetching CSV from URL

app = Flask(__name__)
model_path = r'A:\swyam\crop_rf_model.pkl'
encoder_path = r'A:\swyam\label_encoder.pkl'

model = None
label_encoder = None
try:
  model = joblib.load(model_path)
  label_encoder = joblib.load(encoder_path)
except FileNotFoundError:
  print(f"Error: Model or encoder file not found at {model_path} or {encoder_path}")
  print("Please ensure 'crop_rf_model.pkl' and 'label_encoder.pkl' are in the specified directory.")
DATASET_URL = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Crop_recommendation-vQt5I3TX0Xi9iMwtSTxcaA5dX6fIoC.csv"
df = pd.DataFrame()
try:
  df = pd.read_csv(DATASET_URL)
  print("Dataset loaded successfully from URL.")
except Exception as e:
  print(f"Error fetching or loading dataset from URL: {e}")
  print("Please ensure the URL is correct and accessible.")


@app.route('/analyze')
def analyze():
  plots_dir = 'static/plots'
  if not os.path.exists(plots_dir):
      os.makedirs(plots_dir)

  if not df.empty:
      plt.figure(figsize=(12, 7))
      sns.countplot(data=df, x='label', order=df['label'].value_counts().index, palette='viridis')
      plt.xticks(rotation=90)
      plt.title('Crop Distribution', fontsize=16)
      plt.xlabel('Crop Type', fontsize=12)
      plt.ylabel('Count', fontsize=12)
      plt.tight_layout()
      plt.savefig(os.path.join(plots_dir, 'crop_distribution.png'))
      plt.clf()
      plt.figure(figsize=(10, 8))
      sns.heatmap(df.drop('label', axis=1).corr(), annot=True, fmt=".2f", cmap='coolwarm')
      plt.title("Feature Correlation", fontsize=16)
      plt.tight_layout()
      plt.savefig(os.path.join(plots_dir, 'heatmap.png'))
      plt.clf()

      numerical_features = ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']

      for feature in numerical_features:
          plt.figure(figsize=(8, 5))
          sns.histplot(df[feature], kde=True, color=sns.color_palette("viridis")[0])
          plt.title(f'Distribution of {feature}', fontsize=16)
          plt.xlabel(feature, fontsize=12)
          plt.ylabel('Frequency', fontsize=12)
          plt.tight_layout()
          plt.savefig(os.path.join(plots_dir, f'{feature}_distribution.png'))
          plt.clf()
          plt.figure(figsize=(15, 7)) 
          sns.boxplot(x='label', y=feature, data=df, palette='tab20')
          plt.xticks(rotation=90)
          plt.title(f'{feature} by Crop Type', fontsize=16)
          plt.xlabel('Crop Type', fontsize=12)
          plt.ylabel(feature, fontsize=12)
          plt.tight_layout()
          plt.savefig(os.path.join(plots_dir, f'{feature}_by_crop.png'))
          plt.clf()
  else:
      print("Warning: Dataset is empty, skipping plot generation in /analyze route.")

  return render_template('result.html')

@app.route('/predict', methods=['POST'])
def predict():
  if model is None or label_encoder is None:
      return render_template('result.html', crop="Error: Model not loaded. Check server logs.")

  try:
      features = [float(request.form[key]) for key in ['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']]
      prediction = model.predict([features])
      predicted_crop = label_encoder.inverse_transform(prediction)[0]
      return render_template('result.html', crop=predicted_crop)
  except Exception as e:
      return render_template('result.html', crop=f"Prediction Error: {e}")

@app.route('/')
def index():
  return render_template('index.html')

if __name__ == '__main__':
  app.run(debug=True)
